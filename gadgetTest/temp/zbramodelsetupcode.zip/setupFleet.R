## setup landings for long line fishery
comm.landings <- read.table(paste(getwd(), gs.data$dir,
								  'WGTS/out.fit/zbra.prey', sep='/'), 
							comment.char = ';')
names(comm.landings) <- 
	c('year', 'month', 'area', 'age', 'length',
	  'number.consumed', 'weight', 'mortality')

comm.totals <- 
	filter(comm.landings, year >= 1948) %>%
	select(year, month, area, age, weight) %>%
	mutate(area = as.numeric(as.character(gsub('area', '', area)))) %>%
	group_by(year, month) %>%
	summarize(weight = sum(weight))

## set up and make surveys as fleet
igfs.landings <- structure(data.frame(year=defaults$data.years, step=2, area=1, number=1),
                           area_group=mfdb_group(`1` = 1))
aut.landings <- structure(data.frame(year=defaults$data.years, step=4, area=1, number=1),
          area_group=mfdb_group(`1` = 1))


gadgetfleet('Modelfiles/fleet', gd$dir, missingOkay=T) %>%
    gadget_update('totalfleet',
                  name = 'spr',
                  suitability = fleet.suit('spr', stocknames, 'constant'),
                  data=igfs.landings) %>%
    gadget_update('totalfleet',
                  name = 'aut', 
                  suitability = fleet.suit('aut', stocknames, 'constant'),
                  data = aut.landings) %>%
    gadget_update('totalfleet',
                  name = 'comm',
                  suitability = fleet.suit('comm', stocknames, 'exponentiall50'),
                  data = comm.landings[[1]]) %>%
    # gadget_update('totalfleet',
    #               name = 'discards',
    #               suitability = fleet.suit('discards', stocknames, 'exponentiall50'),
    #               data = discards[[1]]) %>%
    write.gadget.file(gd$dir)
