# setup time and area files


## write out area and time files
gadgetfile('time',
           file_type = 'time',
           components = list(list(firstyear = st.year,
                                  firststep = 1,
                                  lastyear = end.year,
                                  laststep = 4,
                                  notimesteps = c(12,rep(1, 12))))) %>%
    write.gadget.file(gd$dir)


dir.create(paste(getwd(), gd$dir, 'Modelfiles', sep='/'))
file.copy(paste(getwd(), gs.data$dir, 'Modelfiles/area', sep='/'),
		  paste(getwd(), gd$dir, 'Modelfiles/area', sep='/'))

